**nn-search2** is a part-of-speech tagging and text search application.
It uses state-of-the-art pos-tagger based on Averaged Perceptron which provides
fast and accurate results.
Above that, one of the main **nn-search2** features is full text part-of-speech
search extended with word ranges such that you can find chains of nouns, verbs,
adjectives and phrases or even fixed expressions.


